import Foundation

//@author: Luis Leal

//Datos originales 
var data:[Int] = [3,6,9,2,4,1]
//Resultado de los números menores a 5 del arreglo data
var result:[Int] = []
//Para elemento en mi arreglo data
for index in data {
    //Comprueba si el elemento es menor a 5
    if index < 5 {
        //En caso de que lo sea, quiero que lo guardes en 
        //el arreglo result
        result.append(index)
    }
}
//Imprime el arreglo con los números menores a 5
print("Los números menores a 5 son: \(result)")
print("________")


//Crea la función suma que reciba dos parámetros de tipo entero
// regresando la suma de ambos números
func add(a:Int, b:Int) -> Int {
    return a+b
}
print("La suma de 99 + 1 es: ",add(a:99,b:1))
print("________")



//Crea la función potencia que reciba dos parámetros de tipo entero,el primer parámetro para
// el número base y el segundo la potencia a elevar, regresando el resultado de la potencia.
func pown (nb: Int, p: Int) -> Int {
    //Resutlado total es igual al número base que recibimos por parámetro 
    var result = nb
    //Valor de la potencia
    var pown = p
    //Mientras la potencia sea mayor a 1
    while pown > 1 {
        //El resultado lo multiplicamos por el número base
        result = result * nb;
        //Restamos una unidad para se vaya reduciendo la variable pown y salir del ciclo
        pown -= 1
    }
    return result
}
print("4 elevado a la 2 es igual a:",pown(nb:4,p:2))
print("________")


//Declaración de la enumeración
enum months{
        case enero, febrero, marzo, abril, mayo, junio,
        julio, agosto, septiembre, octubre, noviembre, diciembre
}

func idMonth(month:months)-> months{
    switch month{
        case .enero: 
        print("Mes #1")
        break
        case .febrero:
        print("Mes #2")
        break
        case .marzo:
        print("Mes #3")
        break
        case .abril:
        print("Mes #4")
        break
        case .mayo:
        print("Mes #5")
        break
        case .junio:
        print("Mes #6")
        break
        case .julio:
        print("Mes #7")
        break
        case .agosto:
        print("Mes #8")
        break
        case .septiembre:
        print("Mes #9")
        break
        case .octubre:
        print("Mes#10")
        break
        case .noviembre:
        print("Mes #11")
        break
        case .diciembre:
        print("Mes #12")
        break
    }
    return month
}
print(idMonth(month: .abril))